﻿-- Tao bang
CREATE table KHACHHANG(
	ma_KhachHang int primary KEY NOT NULL,
	ten nvarchar(50) NOT NULL,
	ho nvarchar(50) NOT NULL,
	so_DienThoai char(10) NOT NULL,
	email varchar(100) NOT NULL,
	tinh_DiaChi nvarchar(50) NOT NULL,
	huyen_DiaChi nvarchar(50) NOT NULL,
	xa_DiaChi nvarchar(50) NOT NULL
)

create table CUAHANG(
	ma_CuaHang int primary KEY NOT NULL,
	ten_CuaHang nvarchar(100) NOT NULL,
	so_DienThoai char(10) DEFAULT NULL,
	email varchar(100) NOT NULL,
	tinh_DiaChi nvarchar(50) NOT NULL ,
	huyen_DiaChi nvarchar(50) DEFAULT NULL,
	xa_DiaChi nvarchar(50) DEFAULT NULL
)

create table NHANVIEN(
	ma_NhanVien int primary KEY NOT NULL,
	ten nvarchar(50) DEFAULT NULL,
	ho nvarchar(50) NOT NULL,
	email varchar(100) NOT NULL,
	so_DienThoai char(10) DEFAULT NULL,
	dang_LamViec BIT NOT NULL,
	ma_CuaHang int FOREIGN KEY REFERENCES CUAHANG(ma_CuaHang) ON DELETE CASCADE ON UPDATE CASCADE NOT NULL ,
	ma_NguoiQL int FOREIGN KEY REFERENCES NHANVIEN(ma_NhanVien) DEFAULT NULL
)

create table NHASX (
	ma_NhaSX int PRIMARY KEY NOT NULL,
	ten_NhaSX nvarchar(100) DEFAULT NULL
)

create table LOAISP(
	ma_LoaiSP int primary KEY NOT NULL,
	ten_LoaiSP nvarchar(100) DEFAULT NULL
)
create table SANPHAM(
	ma_SanPham int primary KEY NOT NULL,
	ten_SanPham nvarchar(100) NOT NULL,
	ma_NhaSX int foreign key references NHASX(ma_NhaSX) ON DELETE CASCADE ON UPDATE CASCADE,
	ma_LoaiSP int foreign key references LOAISP(ma_LoaiSP) ON DELETE CASCADE ON UPDATE CASCADE,
	nam INT DEFAULT NULL,
	giaBan INT NOT NULL,
	CONSTRAINT check_nam CHECK(nam <= YEAR(GETDATE()))
)

create table KHO(
	ma_CuaHang INT REFERENCES dbo.CUAHANG(ma_CuaHang) ON DELETE CASCADE ON UPDATE CASCADE NOT NULL ,
	ma_SanPham INT REFERENCES dbo.SANPHAM(ma_SanPham) ON DELETE CASCADE ON UPDATE CASCADE NOT NULL,
	soLuong INT NOT NULL,
	PRIMARY KEY(ma_CuaHang,ma_SanPham) 
)

create table HOADON(
	so_HoaDon int primary KEY NOT NULL,
	ma_KhachHang int foreign key references KHACHHANG(ma_KHACHHANG) ON DELETE CASCADE ON UPDATE CASCADE NOT NULL,
	trangthai_HoaDon INT NOT NULL,
	ngay_HoaDon DATETIME DEFAULT GETDATE() ,
	ngay_GHDuKien DATE DEFAULT NULL,
	ngay_GHThucTe DATE DEFAULT NULL,
	ma_CuaHang int FOREIGN KEY REFERENCES CUAHANG(ma_CuaHang) ON DELETE CASCADE ON UPDATE CASCADE,
	ma_NhanVien int FOREIGN KEY REFERENCES NHANVIEN(ma_NhanVien),
	CONSTRAINT check_trangthai CHECK(trangthai_HoaDon = 1 OR trangthai_HoaDon = 2 OR trangthai_HoaDon = 3 OR trangthai_HoaDon = 4),
	CONSTRAINT check_ngayGHDuKien CHECK(ngay_GHDuKien >= ngay_HoaDon)
)

create table CTHD(
	so_HoaDon int FOREIGN KEY REFERENCES HOADON(so_HoaDon) ON DELETE CASCADE ON UPDATE CASCADE NOT NULL,
	ma_ChiecXe INT NOT NULL,
	ma_SanPham int FOREIGN KEY REFERENCES SANPHAM(ma_SanPham) ON DELETE CASCADE ON UPDATE CASCADE NOT NULL,
	soLuong INT NOT NULL,
	giaBan INT NOT NULL,
	giamGia INT NOT NULL,
	PRIMARY KEY(so_HoaDon,ma_ChiecXe)
)

-- Tao du lieu
INSERT [dbo].[NHASX] ([ma_NhaSX], [ten_NhaSX]) VALUES (1, N'Haro')
INSERT [dbo].[NHASX] ([ma_NhaSX], [ten_NhaSX]) VALUES (2, N'Sun Bicycles')
INSERT [dbo].[NHASX] ([ma_NhaSX], [ten_NhaSX]) VALUES (3, N'Merida')
INSERT [dbo].[LOAISP] ([ma_LoaiSP], [ten_LoaiSP]) VALUES (1, N'Xe đạp đua')
INSERT [dbo].[LOAISP] ([ma_LoaiSP], [ten_LoaiSP]) VALUES (2, N'Xe đạp cào cào')
INSERT [dbo].[LOAISP] ([ma_LoaiSP], [ten_LoaiSP]) VALUES (3, N'Xe đạp du lịch')
INSERT [dbo].[LOAISP] ([ma_LoaiSP], [ten_LoaiSP]) VALUES (4, N'Xe đạp đường phố mini')
INSERT [dbo].[SANPHAM] ([ma_SanPham], [ten_SanPham], [ma_NhaSX], [ma_LoaiSP], [nam], [giaBan]) VALUES (1, N'HaroX1', 1, 1, 2020, 1500)
INSERT [dbo].[SANPHAM] ([ma_SanPham], [ten_SanPham], [ma_NhaSX], [ma_LoaiSP], [nam], [giaBan]) VALUES (2, N'HaroM2', 1, 4, 2021, 1100)
INSERT [dbo].[SANPHAM] ([ma_SanPham], [ten_SanPham], [ma_NhaSX], [ma_LoaiSP], [nam], [giaBan]) VALUES (3, N'SunA3', 2, 1, 2021, 2000)
INSERT [dbo].[SANPHAM] ([ma_SanPham], [ten_SanPham], [ma_NhaSX], [ma_LoaiSP], [nam], [giaBan]) VALUES (4, N'MeridaL1', 3, 2, 2020, 3000)
INSERT [dbo].[SANPHAM] ([ma_SanPham], [ten_SanPham], [ma_NhaSX], [ma_LoaiSP], [nam], [giaBan]) VALUES (5, N'SunM1', 2, 3, 2021, 1500)
INSERT [dbo].[KHACHHANG] ([ma_KhachHang], [ten], [ho], [so_DienThoai], [email], [tinh_DiaChi], [huyen_DiaChi], [xa_DiaChi]) VALUES (1, N'Mai', N'Nguyễn', N'0548733625', N'mai@gmail.com', N'Đà Nẵng', N'Hải Châu', N'Thanh Bình')
INSERT [dbo].[KHACHHANG] ([ma_KhachHang], [ten], [ho], [so_DienThoai], [email], [tinh_DiaChi], [huyen_DiaChi], [xa_DiaChi]) VALUES (2, N'Lợi', N'Thái Đình', N'0984257156', N'loi@gmail.com', N'Hà Nội', N'Thanh Xuân', N'Khương Đình')
INSERT [dbo].[KHACHHANG] ([ma_KhachHang], [ten], [ho], [so_DienThoai], [email], [tinh_DiaChi], [huyen_DiaChi], [xa_DiaChi]) VALUES (3, N'Hà', N'Nguyễn Thanh', N'0258463595', N'ha@gmail.com', N'Hồ Chí Minh', N'Quận 10', N'Phường 1')
INSERT [dbo].[CUAHANG] ([ma_CuaHang], [ten_CuaHang], [so_DienThoai], [email], [tinh_DiaChi], [huyen_DiaChi], [xa_DiaChi]) VALUES (1, N'Hường Bike', N'0389562548', N'huong@gmail.com', N'Hà Nội', N'Bắc Từ Liêm', N'Cổ Nhuế 1')
INSERT [dbo].[CUAHANG] ([ma_CuaHang], [ten_CuaHang], [so_DienThoai], [email], [tinh_DiaChi], [huyen_DiaChi], [xa_DiaChi]) VALUES (2, N'Linh Đan', N'0358746521', N'linhdan@gmail.com', N'Hà Nội', N'Ba Đình', N'Giảng Võ')
INSERT [dbo].[CUAHANG] ([ma_CuaHang], [ten_CuaHang], [so_DienThoai], [email], [tinh_DiaChi], [huyen_DiaChi], [xa_DiaChi]) VALUES (3, N'Ngọc Hưng', N'0384126852', N'ngochung@gmail.com', N'Hồ Chí Minh', N'Quận 1', N'Bến Thành')
INSERT [dbo].[NHANVIEN] ([ma_NhanVien], [ten], [ho], [email], [so_DienThoai], [dang_LamViec], [ma_CuaHang], [ma_NguoiQL]) VALUES (1, N'Linh', N'Nguyễn', N'linh@gmail.com', N'0284953687', 1, 1, NULL)
INSERT [dbo].[NHANVIEN] ([ma_NhanVien], [ten], [ho], [email], [so_DienThoai], [dang_LamViec], [ma_CuaHang], [ma_NguoiQL]) VALUES (2, N'Ngọc', N'Đinh Thị', N'ngoc@gmail.com', N'0584632547', 1, 1, 1)
INSERT [dbo].[NHANVIEN] ([ma_NhanVien], [ten], [ho], [email], [so_DienThoai], [dang_LamViec], [ma_CuaHang], [ma_NguoiQL]) VALUES (3, N'Hưng', N'Trần Đình', N'hung@gmail.com', N'0984535842', 0, 2, NULL)
INSERT [dbo].[KHO] ([ma_CuaHang], [ma_SanPham], [soLuong]) VALUES (1, 1, 10)
INSERT [dbo].[KHO] ([ma_CuaHang], [ma_SanPham], [soLuong]) VALUES (1, 2, 15)
INSERT [dbo].[KHO] ([ma_CuaHang], [ma_SanPham], [soLuong]) VALUES (1, 5, 5)
INSERT [dbo].[KHO] ([ma_CuaHang], [ma_SanPham], [soLuong]) VALUES (2, 2, 7)
INSERT [dbo].[KHO] ([ma_CuaHang], [ma_SanPham], [soLuong]) VALUES (2, 3, 20)
INSERT [dbo].[KHO] ([ma_CuaHang], [ma_SanPham], [soLuong]) VALUES (3, 4, 30)
INSERT [dbo].[KHO] ([ma_CuaHang], [ma_SanPham], [soLuong]) VALUES (3, 5, 25)
INSERT [dbo].[KHO] ([ma_CuaHang], [ma_SanPham], [soLuong]) VALUES (2, 1, 10)
INSERT [dbo].[KHO] ([ma_CuaHang], [ma_SanPham], [soLuong]) VALUES (2, 5, 10)
INSERT [dbo].[KHO] ([ma_CuaHang], [ma_SanPham], [soLuong]) VALUES (3, 1, 15)
INSERT [dbo].[HOADON] ([so_HoaDon], [ma_KhachHang], [trangthai_HoaDon], [ngay_HoaDon], [ngay_GHDuKien], [ngay_GHThucTe], [ma_CuaHang], [ma_NhanVien]) VALUES (1, 1, 1, CAST(N'2021-12-08T20:34:32.033' AS DateTime), CAST(N'2021-12-10' AS Date), NULL, 1, 3)
INSERT [dbo].[HOADON] ([so_HoaDon], [ma_KhachHang], [trangthai_HoaDon], [ngay_HoaDon], [ngay_GHDuKien], [ngay_GHThucTe], [ma_CuaHang], [ma_NhanVien]) VALUES (2, 3, 4, CAST(N'2020-05-08T20:35:04.333' AS DateTime), CAST(N'2020-05-10' AS Date), CAST(N'2020-05-09' AS Date), 2, 2)
INSERT [dbo].[HOADON] ([so_HoaDon], [ma_KhachHang], [trangthai_HoaDon], [ngay_HoaDon], [ngay_GHDuKien], [ngay_GHThucTe], [ma_CuaHang], [ma_NhanVien]) VALUES (3, 2, 2, CAST(N'2021-12-08T20:35:56.577' AS DateTime), CAST(N'2021-12-20' AS Date), NULL, 1, 1)
INSERT [dbo].[CTHD] ([so_HoaDon], [ma_ChiecXe], [ma_SanPham], [soLuong], [giaBan], [giamGia]) VALUES (1, 1, 1, 1, 1300, 200)
INSERT [dbo].[CTHD] ([so_HoaDon], [ma_ChiecXe], [ma_SanPham], [soLuong], [giaBan], [giamGia]) VALUES (1, 2, 3, 2, 2200, 0)
INSERT [dbo].[CTHD] ([so_HoaDon], [ma_ChiecXe], [ma_SanPham], [soLuong], [giaBan], [giamGia]) VALUES (2, 3, 1, 1, 1500, 0)
INSERT [dbo].[CTHD] ([so_HoaDon], [ma_ChiecXe], [ma_SanPham], [soLuong], [giaBan], [giamGia]) VALUES (3, 4, 4, 3, 3200, 0)
INSERT [dbo].[CTHD] ([so_HoaDon], [ma_ChiecXe], [ma_SanPham], [soLuong], [giaBan], [giamGia]) VALUES (3, 5, 2, 1, 1100, 0)


-- Dua ra thong tin nhan vien va hoa don lap duoc truoc ngay '2021-05-05'
SELECT *
FROM dbo.NHANVIEN nv, dbo.HOADON hd
WHERE nv.ma_NhanVien = hd.ma_NhanVien AND hd.ngay_HoaDon <= '2021-05-05'

-- Dua ra thong tin san pham, hoa don va nhan vien lap hoa don voi san pham co gia tu 1500
-- tro len do nhan vien co ten 'Hung' ban duoc
SELECT * 
FROM dbo.SANPHAM sp, dbo.NHANVIEN nv, dbo.HOADON hd,dbo.CTHD cthd
WHERE nv.ma_NhanVien = hd.ma_NhanVien 
	AND hd.so_HoaDon = cthd.so_HoaDon
	AND cthd.ma_SanPham = sp.ma_SanPham
	AND nv.ten = N'Hưng' AND cthd.giaBan >=1500

--Thong ke so lan mua hang cua cac khach hang tren tat ca cac cua hang
SELECT kh.ma_KhachHang, kh.ho, kh.ten, COUNT(*) AS 'solanmuahang'
FROM dbo.KHACHHANG kh, dbo.HOADON hd
WHERE kh.ma_KhachHang = hd.ma_KhachHang
GROUP BY kh.ma_KhachHang, kh.ho, kh.ten

--Liet ke nhung cua hang chua trong kho tat ca cac xe dap cua nha san xuat 'Sun Bicycles'
SELECT dbo.CUAHANG.ma_CuaHang, ten_CuaHang FROM dbo.KHO, dbo.CUAHANG, dbo.SANPHAM, dbo.NHASX
WHERE dbo.KHO.ma_CuaHang = dbo.CUAHANG.ma_CuaHang
	AND KHO.ma_SanPham = SANPHAM.ma_SanPham
	AND dbo.SANPHAM.ma_NhaSX = dbo.NHASX.ma_NhaSX
	AND ten_NhaSX = N'Sun Bicycles'
GROUP BY CUAHANG.ma_CuaHang, ten_CuaHang
HAVING COUNT(dbo.KHO.ma_SanPham) = (SELECT COUNT(ma_SanPham) AS soluong 
									FROM dbo.SANPHAM, dbo.NHASX 
									WHERE dbo.NHASX.ma_NhaSX = dbo.SANPHAM.ma_NhaSX 
					AND ten_NhaSX = N'Sun Bicycles' )

-- Tim cac san pham co trong tat ca cac cua hang
SELECT DISTINCT kh.ma_SanPham
FROM dbo.KHO kh
WHERE NOT EXISTS(
SELECT ch.ma_CuaHang FROM dbo.CUAHANG AS ch WHERE NOT EXISTS(
SELECT * FROM dbo.KHO kh2
WHERE kh2.ma_CuaHang= ch.ma_CuaHang AND kh2.ma_SanPham = kh.ma_SanPham))












